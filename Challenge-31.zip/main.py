"""
write a function called liner_search_product that takes the list of products and a target product
name as input.The function should perform a linear search to find the target product in the list and
return a list of indices of all occurrences of the if the product is not
found. 
"""


def Linearsearchproduct(productList, targetproduct):
  indices = []

  for index,product in enumerate(productList):     
    if product == targetproduct:
      indices.append(index)
  return indices



# Example usage:
products=["shoes","boot", "Loafer", "shoes", "sandle", "shoes"]
target = "shoes"
target2 = "apple"
result = Linearsearchproduct(products, target)
print(result)
