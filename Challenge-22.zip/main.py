'''implement a class called player that represent a cricket player.the player class should have a
method called paly()which prints"the player is playing cricket.Derive two classes Batsman and
Blower,from the player class. override the play()method in each derived    class to print"The batsman            
is batting"and"the"bowler is bowling",  respectively.write a prderidedo create  object of both the
Batsman and Boweler classes and call the play()method for each               objects.'''


# define the base class player
class player:

  def play(self):
    print("The player is playing cricket.")


# define the derived class Batsman
class Batsman(player):

  def play(self):
    print("The batsman is batting.")


#define the derived class Blower
class Bowler(player):

  def play(self):
    print("The bowler is bowling.")


# create objects of Batsman and Bowler classes
batsman = Batsman()
bowler = Bowler()

# call the play()method for each object
batsman.play()
bowler.play()


class player:

  def play(self):
    print("The player is playing")


class batsman(player):

  def play(self):
    super().play()
    print("The batsman is batting")


class bowler(batsman):

  def play(self):
    super().play()
    print("The bowler is bowling")


s = bowler
s.play
